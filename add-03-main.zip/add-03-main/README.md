# Termistor - NTC


Alumno:Ferrante Santino

Curso: 5°1° AVC

Materia: Adquisicion de Datos
